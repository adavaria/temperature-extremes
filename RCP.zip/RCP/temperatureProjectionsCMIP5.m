function [ti, Tmax, Tmean, Tmin]=temperatureProjectionsCMIP5()
% load CMIP5 temperature projections. SeanV.
%clear all; close all; clc;

DATA_DIR='tempScenarios';

RCP={'rcp26','rcp45','rcp60','rcp85'};  

files=dir([DATA_DIR, filesep,'*',RCP{4},'*.dat']);

filenames={files.name}';

ti=(datenum(2000,1,1):30:datenum(2300,1,1));

for i=1:length(filenames)
    fileID = fopen([DATA_DIR,filesep,filenames{i}]);
    C = textscan(fileID,'%d \t %f \t %f \t %f \t %f \t %f \t %f \t %f \t %f \t %f \t %f \t %f \t %f','headerlines',5);
    fclose(fileID);
    
    YYYY=double(reshape(repmat(C{:,1}',12,1),[],1));
    MM=repmat((1:12)',length(C{:,1}),1);
    t=datenum(YYYY,MM,1);
    T=reshape(cell2mat(C(:,2:end))',[],1)-273.15;
    
    N=50;
    Ttmp=[flipud(T(1:N)); T; flipud(T(end-N:end))];
    [b,a] = butter(2,0.02,'low');
    Tsmooth=filtfilt(b,a,Ttmp);
    Tsmooth=Tsmooth(N+1:end-N-1);

    TEMP(:,i)=interp1(t,Tsmooth,ti); %#ok<AGROW>
    
end

TEMP(:,41) = NaN(3653,1);

TEMP=TEMP-repmat(TEMP(1,:),length(ti),1);

% Tmean1=nanmean(TEMP-repmat(TEMP(1,:),size(TEMP,1),1),2);
Tmean1=mean(TEMP-repmat(TEMP(1,:),size(TEMP,1),1),2,'omitnan');
DT=diff(Tmean1);

% figure;
% plot(ti,TEMP,'b',ti,Tmean1,'r');

id=abs(DT)>1e-2;
% figure;
% plot(ti(2:end),DT,'b',ti(id),DT(id),'ro');

DT(id)=mean(DT);
Tmean=cumsum([0; DT]);

% figure;
% plot(ti,TEMP,'b',ti,Tmean,'r');
% datetick('x')

% This considers the last point of the senatio as if it is high-end or low
% end
[~,id]=max(TEMP(end,:)); Tmax=TEMP(:,id)-TEMP(1,id); %filenames{id}; max(Tmax);
[~,id]=min(TEMP(end,:)); Tmin=TEMP(:,id)-TEMP(1,id); %filenames{id}; max(Tmin);
Tmax_sean = Tmax;
Tmin_sean = Tmin;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Hence we change this to the average of the 10 worsts and 10 bests at each
% time section. So we might be switching between different research.
% NEW CODE by ALI:

% Considering long senarrios:

long_sen = ~isnan(TEMP(end,:));
% A = TEMP(:,long_sen);
% A = sort(A, 2);
% Tmax_long=A(:,end);
% Tmin_long=A(:,1);
% Tmean_long = mean(A, 2);
% 
% figure
% p = plot(ti, TEMP(:,~long_sen), 'b', ti, TEMP(:,long_sen), 'k', ti, Tmax_long,'r', ti,Tmin_long, 'g', ti, Tmean_long, 'm');
% datetick('x')
% for i = 1:length(p)
%     p(i).LineWidth = 2;
% end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Considering all the senarrios 

n = 4;

A = TEMP;
A(isnan(A))=-2;
A = sort(A, 2);
Tmax=mean(A(:,end-n+1:end),2);
% Tmax=A(:,end);
DT=diff(Tmax);
id=abs(DT)>1e-1;
DT(id)=mean(DT);
Tmax=cumsum([0; DT]);

A = TEMP;
A(isnan(A))=100;
A = sort(A, 2);
Tmin=mean(A(:,1:n),2);
% Tmin=A(:,1);
DT=diff(Tmin);
id=abs(DT)>1e-1;
DT(id)=mean(DT);
Tmin=cumsum([0; DT]);

% N=50;
% Ttmp=Tmax;
% Ttmp=[flipud(Ttmp(1:N)); Ttmp; flipud(Ttmp(end-N:end))];
% [b,a] = butter(2,0.02,'low');
% Tsmooth=filtfilt(b,a,Ttmp);
% Tsmooth=Tsmooth(N+1:end-N-1);
% Tmax_b = Tsmooth;


% figure;
% p = plot(ti, TEMP(:,~long_sen), 'b', ti, TEMP(:,long_sen), 'k', ti, Tmax,'r', ti,Tmin, 'g', ti, Tmean, 'm');
% datetick('x');
% for i = 1:length(p)
%     p(i).LineWidth = 2;
% end
% figure;
% p = plot(ti, TEMP(:,~long_sen), 'b', ti, TEMP(:,long_sen), 'k');
% datetick('x');
% for i = 1:length(p)
%     p(i).LineWidth = 2;
% end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Comparision:

% figure
% % p = plot(ti, Tmax,'r', ti,Tmin, 'r', ti, Tmean, 'r', ti, Tmax_long,'b', ti,Tmin_long, 'b', ti, Tmean_long, 'b');
% p = plot(ti, [Tmax,Tmin,Tmean], 'r', ti, [Tmax_long,Tmin_long, Tmean_long], 'b', ti, [Tmax_sean, Tmin_sean], 'g');
% datetick('x')
% for i = 1:length(p)
%     p(i).LineWidth = 2;
% end
% legend('All', 'Only long sen.', 'Sean')




% figure;
% plot(ti,TEMP,'b',ti,Tmean,'k',ti,Tmax,'r',ti,Tmin,'g');
% plot(ti,Tmean,'k',ti,Tmax,'r');
% datetick('x')


% [~,id]=min(abs(TEMP(end,:)-9.5)); Tmean_mod=TEMP(:,id)-TEMP(1,id); filenames{id}; max(Tmean_mod);

