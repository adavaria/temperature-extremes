% load CMIP5 temperature projections. SeanV.
clear all; close all; clc;

DATA_DIR='tempScenarios';

RCP={'rcp26','rcp45','rcp60','rcp85'};  

files=dir([DATA_DIR, filesep,'*',RCP{4},'*.dat']);


filenames={files.name}';

% filenames={'iglobal_tas_Amon_modmean_rcp26_000.dat',...
%            'iglobal_tas_Amon_modmean_rcp45_000.dat',...
%            'iglobal_tas_Amon_modmean_rcp60_000.dat',...
%            'iglobal_tas_Amon_modmean_rcp85_000.dat'};
% 
%      
% 
% % filenames={'global_tas_Amon_GFDL-ESM2M_rcp85_r1i1p1.dat'};
% filenames={'global_tas_Amon_GISS-E2-H_rcp85_r1i1p3.dat'};

ti=(datenum(2000,1,1):30:datenum(2300,1,1));
TEMP = nan(size(ti,2), length(filenames));

for i=1:length(filenames)
    fileID = fopen([DATA_DIR,filesep,filenames{i}]);
    C = textscan(fileID,'%d \t %f \t %f \t %f \t %f \t %f \t %f \t %f \t %f \t %f \t %f \t %f \t %f','headerlines',5);
    fclose(fileID);
    
    YYYY=double(reshape(repmat(C{:,1}',12,1),[],1));
    MM=repmat((1:12)',length(C{:,1}),1);
    t=datenum(YYYY,MM,1);
    T=reshape(cell2mat(C(:,2:end))',[],1)-273.15;
    
    N=50;
    Ttmp=[flipud(T(1:N)); T; flipud(T(end-N:end))];
    [b,a] = butter(2,0.02,'low');
    Tsmooth=filtfilt(b,a,Ttmp);
    Tsmooth=Tsmooth(N+1:end-N-1);

    TEMP(:,i)=interp1(t,Tsmooth,ti);
    
end

% plot(ti,TEMP-repmat(TEMP(1,:),size(TEMP,1),1),'b',ti,nanmean(TEMP-repmat(TEMP(1,:),size(TEMP,1),1),2),'r'); datetick('x')


TEMP=TEMP-repmat(TEMP(1,:),length(ti),1);

Tmean1=nanmean(TEMP-repmat(TEMP(1,:),size(TEMP,1),1),2);
DT=diff(Tmean1);

figure;
hline = plot(ti,TEMP,'b',ti,Tmean1,'r');
% for i=1:length(hline)
%     hline(i).Color = [hline(i).Color 0.3];  % alpha=0.1
% end
datetick('x')
axis([datenum(2000,1,1) datenum(2100,1,1) 0 6]);


id=abs(DT)>1e-2;
% figure;
% plot(ti(2:end),DT,'b',ti(id),DT(id),'ro');

DT(id)=mean(DT);
Tmean=cumsum([0; DT]);

[~,id]=max(TEMP(end,:)); 
Tmax=TEMP(:,id)-TEMP(1,id); %filenames{id}; max(Tmax);

[~,id]=min(TEMP(end,:)); 
Tmin=TEMP(:,id)-TEMP(1,id); %filenames{id}; max(Tmin);

A = sort(TEMP, 2);
Tmax2=mean(A(:,end-10:end), 2);
Tmin2=mean(A(:,1:10), 2);


figure; 
hold on; 
plot(ti, Tmean, 'LineWidth',2)
plot(ti, Tmax, 'LineWidth',2)
% plot(ti, Tmax2, 'LineWidth',2)
plot(ti, Tmin, 'LineWidth',2)
% plot(ti, Tmin2, 'LineWidth',2)
datetick('x')
% legend('Tmean', 'Tmax', 'Tmax2', 'Tmin', 'Tmin2')
axis([datenum(2000,1,1) datenum(2100,1,1) 0 6]);

Tmin = Tmin2;
Tmax = Tmax2;

[~,id]=min(abs(TEMP(end,:)-9.5)); 
Tmean_mod=TEMP(:,id)-TEMP(1,id); filenames{id}; max(Tmean_mod);




% stop

% t0=t(1);
% t2000=datenum(2000,1,1);
% tf=datenum(2300,1,1);
% 
% TEMP=TEMP-repmat(TEMP(t==t2000,:),length(t),1);
% 
% figure(1); set(gcf,'PaperPositionMode','auto','Position',[200 200 800 600]); hold on; box on;
% han1=plot(t,TEMP); set(han1,'LineWidth',2);
% 
% plot([t2000 t2000],[-1.5 7],'k--')
% axis([t0 tf -1.5 7]); datetick('x','keeplimits');
% ylabel('Global Temperature [Deg C]');
% han1=legend(RCP); set(han1,'location','northwest');
% 
% set(gca,'FontSize',14);
% 
% print(gcf,'ensembleMeanTemp.jpg','-djpeg','-r300');